Please find new modules / extensions / plugins for diverse e-commerce systems at 
http://www.ajax-zoom.com/index.php?cid=modules